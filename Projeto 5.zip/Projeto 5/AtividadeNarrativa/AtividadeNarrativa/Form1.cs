﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeNarrativa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
 
            //entrada
            float valor = float.Parse(textBox1.Text);
            float resultado;

            //calcule
            resultado = valor * 0.10f;

            //saida
            MessageBox.Show("valor em resultado: " + resultado);
        }
    }
}

